Registro de Carreras y Cálculo de Campeones
-
Este script de Python permite registrar los resultados de múltiples carreras de competidores y calcular el campeón basado en varios sistemas de puntajes. Cada sistema de puntajes puede tener de 1 a 10 valores que se asignan a los competidores según su orden de llegada en cada carrera.

Funcionalidad
-
El script realiza lo siguiente:

Solicita al usuario ingresar la cantidad de carreras y competidores.
Permite la entrada de varios sistemas de puntajes.
Registra el orden de llegada de los competidores para cada carrera.
Calcula los puntajes totales de cada competidor según cada sistema de puntajes.
Determina y anuncia los campeones basado en los puntajes acumulados.

Cómo Usar
-
Requisitos
-
Asegúrate de tener Python 3 instalado en tu máquina. Puedes descargarlo desde Python.org.

Ejecución
-
Guarda el script en un archivo, por ejemplo carreras_puntajes.py.
Abre una terminal o línea de comandos.
Navega al directorio donde está guardado el archivo.
Ejecuta el script con el comando:

python carreras_puntajes.py

Sigue las instrucciones en pantalla para ingresar los datos de las carreras y los sistemas de puntajes.

Entrada de Datos
-
Número de Carreras y Competidores: Introduce el total de carreras y el número de competidores en cada carrera.
Sistemas de Puntajes: Para cada sistema, introduce los valores de puntajes separados por espacio. Puedes introducir de 1 a 10 puntajes por sistema.
Orden de Llegada: Para cada carrera, introduce el orden en que los competidores cruzaron la meta, separados por espacio.
Ejemplo de Entrada
"
Ingresa la cantidad de carreras: 2
Ingresa la cantidad de competidores por carrera: 3
Ingresa el número de sistemas de puntajes: 2
Ingresa los puntajes para el sistema 1, separados por espacio: 10 6 4
Ingresa los puntajes para el sistema 2, separados por espacio: 5 3 2
Ingresa el orden de llegada de los 3 competidores para la carrera 1: 1 2 3
Ingresa el orden de llegada de los 3 competidores para la carrera 2: 2 1 3"

Contribuciones
-
Las contribuciones a este proyecto son bienvenidas. Por favor, asegúrate de realizar pruebas exhaustivas antes de enviar un pull request.

Licencia
-
Este proyecto está licenciado bajo la Licencia MIT. Consulta el archivo LICENSE para obtener más detalles.