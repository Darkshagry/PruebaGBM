def registrar_resultados_carreras_con_varios_puntajes():
    # Ingresar el número de carreras y el número de competidores por carrera
    G = int(input("Ingresa la cantidad de carreras: "))
    P = int(input("Ingresa la cantidad de competidores por carrera: "))

    # Ingresar el número de sistemas de puntajes
    num_sistemas = int(input("Ingresa el número de sistemas de puntajes: "))
    sistemas_puntajes = []

    # Ingresar cada sistema de puntajes
    for i in range(num_sistemas):
        puntajes = list(map(int, input(f"Ingresa los puntajes para el sistema {i+1}, separados por espacio: ").split()))
        if len(puntajes) < 1 or len(puntajes) > 10:
            print("Error: Cada sistema de puntajes debe tener entre 1 y 10 puntajes.")
            return
        sistemas_puntajes.append(puntajes)

    # Diccionario para almacenar los resultados de cada competidor por cada sistema de puntajes
    resultados_por_sistema = {i: {j+1: 0 for j in range(P)} for i in range(num_sistemas)}

    # Recopilar y procesar el orden de llegada de los competidores para cada carrera
    for i in range(1, G + 1):
        orden_llegada = list(map(int, input(f"Ingresa el orden de llegada de los {P} competidores para la carrera {i}: ").split()))
        if len(orden_llegada) != P or sorted(orden_llegada) != list(range(1, P + 1)):
            print(f"Error: Debe ingresar exactamente {P} competidores en el orden correcto (1 a {P}). Intenta nuevamente.")
            return

        # Asignar puntajes a los competidores basados en su posición de llegada para cada sistema de puntajes
        for idx, competidor in enumerate(orden_llegada):
            for s_idx in range(num_sistemas):
                puntaje = sistemas_puntajes[s_idx][idx] if idx < len(sistemas_puntajes[s_idx]) else 0
                resultados_por_sistema[s_idx][competidor] += puntaje

    # Calcular e imprimir el competidor con el máximo puntaje por cada sistema de puntajes
    for s_idx in range(num_sistemas):
        max_puntaje = max(resultados_por_sistema[s_idx].values())
        campeones = [competidor for competidor in resultados_por_sistema[s_idx] if resultados_por_sistema[s_idx][competidor] == max_puntaje]
        print(f"Sistema de Puntajes {s_idx+1}:")
        for competidor in resultados_por_sistema[s_idx]:
            print(f"Competidor {competidor}: {resultados_por_sistema[s_idx][competidor]}")
        if len(campeones) > 1:
            print("Los campeones son los competidores:", ', '.join(map(str, campeones)))
        else:
            print("El campeón es el competidor:", campeones[0])

# Llamar a la función para ejecutar el programa
registrar_resultados_carreras_con_varios_puntajes()
