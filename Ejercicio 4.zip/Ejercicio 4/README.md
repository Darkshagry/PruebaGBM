Clasificador de Valor de Cliente
-

Descripción
-
Este proyecto desarrolla un modelo de clasificación para segmentar a los clientes de una tienda en tres categorías: bajo, medio y alto valor, basado en su frecuencia de compra y el valor medio gastado por compra. Utiliza Python y scikit-learn para implementar el modelo y emplea técnicas de aprendizaje automático para predecir la categoría de cada cliente. Esto ayuda a la tienda a diseñar campañas de marketing personalizadas para mejorar la retención de clientes y aumentar las ventas.

Tecnologías
-
El proyecto está implementado usando las siguientes tecnologías:

Python 3.8

Pandas para el manejo de datos

scikit-learn para la construcción del modelo de clasificación

Configuración del Entorno

Cómo Ejecutar
Para ejecutar el proyecto y ver los resultados de la clasificación, sigue estos pasos:

Navega al directorio del proyecto en tu terminal.

Ejecuta el script principal:
-

python Clasificacion.py

debes tener la base de datos en la misma carpeta del codigo

Los resultados serán mostrados en la terminal