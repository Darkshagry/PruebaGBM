# Online Python compiler (interpreter) to run Python online.
# Write Python 3 code in this online editor and run it.
def es_palindromo(palabra):
    # Normalizamos la palabra: eliminamos espacios y convertimos a minúscula
    palabra = palabra.replace(" ", "").lower()
    # Comparamos la palabra con su versión invertida
    return palabra == palabra[::-1]
palabra = input("Introduce una palabra para verificar si es un palíndromo: ")
if es_palindromo(palabra): print(f"'{palabra}' es un palíndromo")
else: print(f"'{palabra}' no es un palíndromo")