
# Palíndromo

Detector de Palíndromos
Este script de Python permite determinar si una palabra introducida por el usuario es un palíndromo. Un palíndromo es una palabra o frase que se lee igual hacia adelante que hacia atrás, ignorando espacios, signos de puntuación y diferencias entre mayúsculas y minúsculas.

Requisitos
Para ejecutar este script, necesitarás:

-Python 3.x

Puedes descargar Python aquí: 
Python Official Site

Instalación
-

No es necesaria ninguna instalación adicional de módulos o paquetes para ejecutar este script, ya que utiliza funciones que están incluidas en la biblioteca estándar de Python.

Uso
-
Para utilizar este script, sigue estos pasos:

-Guarda el código en un archivo con extensión .py, por ejemplo detector_palindromos.py.

-Abre una terminal o línea de comandos.

-Navega hasta el directorio donde se encuentra el archivo guardado.

-Ejecuta el script con el comando:

python detector_palindromos.py

-Sigue las instrucciones en pantalla para introducir la palabra que deseas verificar.

-El script te informará si la palabra es un palíndromo o no.

