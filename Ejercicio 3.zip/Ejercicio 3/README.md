Descripción del Problema
-
Dado un punto x en el eje OX, puedes:

Saltar hacia adelante al punto y + k donde y es tu posición actual y k es el número de salto.
Saltar hacia atrás al punto y - 1.
El script calcula el número mínimo de saltos requeridos para llegar a x desde 0.

Cómo Funciona
-
El script lee una cantidad de casos de prueba. Para cada caso de prueba:

Lee el punto objetivo x.

Calcula el número mínimo de saltos requeridos para llegar a x utilizando un algoritmo eficiente que involucra:

Sumar la secuencia de números naturales hasta que la suma sea al menos x.
Ajustar la trayectoria basada en la diferencia entre la suma y x.
Observaciones Clave
Suma de Números Naturales: Sumar números naturales aumenta rápidamente la posición actual.

Manejo de Exceso:

Si la suma supera a x, el script verifica si la diferencia (diff) es par. Si es par, se pueden hacer ajustes sin saltos adicionales; si es impar, se calculan más saltos hasta encontrar un diff par o una coincidencia exacta.
Uso
-
Requisitos
-
Asegúrate de tener Python 3 instalado en tu máquina.

Ejecutando el Script
-
Clona este repositorio o descarga el script.
Abre tu terminal o símbolo del sistema.
Navega hasta la carpeta que contiene el script.

Ejecuta el script usando Python:
-

python min_jumps.py

Formato de Entrada
-

Primero, introduce el número de casos de prueba t.
Para cada caso de prueba, introduce el entero x que representa el punto objetivo en el eje OX.

Salida
-
Para cada caso de prueba, el script muestra el número mínimo de saltos requeridos para alcanzar el punto x.