def min_jumps_to_x(x):
    k = 0
    sum_k = 0
    while True:
        k += 1
        
        if sum_k == x:
            diff = sum_k - x
            if diff == 0:
                return k-1
        if sum_k > x:
            sum_k-=1
        if sum_k < x:
            sum_k += k

t = int(input("ingrese el numero de test"))
results = []
for _ in range(t):
    x = int(input("ingrese x: "))
    results.append(min_jumps_to_x(x))

for result in results:
    print(result)
